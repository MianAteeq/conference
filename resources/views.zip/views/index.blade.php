<!DOCTYPE html>
<html lang="en">

@include('layouts.head')
<style>
    .events-section-title h2 {
    font-size: 2rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #222;
}

.sponsors h3 {
    font-size: 1.2rem;
    margin-bottom: 15px;
    color: #333;
}

.partner-box {
    width: 70%;
    margin: 0 auto;
    transition: transform 0.3s ease;
}

.partner-box:hover {
    transform: scale(1.05);
}

.partner-logo {
    max-width: 100%;
    height: auto;
    border-radius: 10px;
}

.white-bg {
    background: #fff;
    padding: 6px;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

/* Responsive Adjustments */
@media (max-width: 992px) {
    .partner-box {
        width: 80%;
    }
}

@media (max-width: 768px) {
    .events-section-title h2 {
        font-size: 1.6rem;
    }

    .sponsors h3 {
        font-size: 1.1rem;
    }

    .partner-box {
        width: 85%;
    }
    .navbar-brand>img{
        width:230px!important;
    }
}

</style>

<body>

    <!-- start page-wrapper -->
    <div class="page-wrapper" id="home">

        <!-- start preloader -->
        <div class="preloader">
            <div>
                <img src="/assets/logo.gif" alt>
            </div>
        </div>
        <!-- end preloader -->

        <!-- Start header -->
        <header class="events-header">
            <nav class="navigation navbar navbar-default">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="open-btn">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"><img src="https://conference.fissionmonster.com/final_logo.png" alt
                                class="img img-responsive" style="width: 280px;"></a>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse navbar-right">
                        <button class="close-navbar"><i class="fa fa-close"></i></button>
                        <ul class="nav navbar-nav">
                            <li class="current"><a href="#home">Home</a></li>
                            <li><a href="#about">About</a></li>
                            <!--<li><a href="#speakers">Speakers</a></li>-->
                            <li><a href="#schedules">Schedules</a></li>
                            <li><a href="#ticket">Register</a></li>
                            <li><a href="#gallery">Gallery</a></li>
                            <li><a href="#contact">Contact</a></li>
                        </ul>
                    </div><!-- end of nav-collapse -->
                </div><!-- end of container -->
            </nav>
        </header>
        <!-- end of header -->


        <!-- start of hero -->
        <section class="hero parallax events-hero" data-bg-image="/assets/images/events/hero-bg.jpg">
            <div class="hero-title">
                <span>Dec 26 - 28 . Expo Center, Lahore 2025</span>
                <h1>PDA International Conference</h1>
                <ul class="social-links">
                    <li><a href="https://www.facebook.com/profile.php?id=61581195661341&sk=reels_tab"><i
                                class="fa fa-facebook"></i></a></li>
                    <li><a
                            href="https://www.linkedin.com/posts/pda-conference-06b76b388_pdaconference25-dentalconference-pakistandentalassociation-activity-7379932139036860416-JDoi?utm_source=share&utm_medium=member_android&rcm=ACoAADXc-X4BSCHfeBanwTZ_yNBcgem7Qtnhxh4">
                            <i class="fa fa-linkedin"></i></a></li>
                    <li><a
                            href="https://www.instagram.com/pdaconference?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw%3D%3D"><i
                                class="fa fa-instagram"></i></a></li>
                    <li><a href="https://api.whatsapp.com/send?phone=923334214214"><i class="fa fa-whatsapp"></i></a>
                    </li>

                </ul>
                <img src="https://conference.fissionmonster.com/logo_white.png" alt="" class="img img-responsive" style="text-align: center;margin: 0 auto;width: 50%;">
            </div>
        </section>
        <!-- end of hero -->


        <!-- start events-about -->
        <section class="events-about section-padding" id="about">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-10 col-lg-offset-1">
                        <div class="row">
                            <div class="col col-md-5 left-col">
                                <div class="img-holder">
                                    <img src="/assets/images/events/about.jpg" alt class="img img-responsive">

                                    <div class="date">
                                        <span>26-28</span> Dec '2025
                                    </div>
                                </div>
                            </div>

                            <div class="col col-md-7 right-col">
                                <div class="title">
                                    <span>Pakistan Dental Association presents</span>
                                    <h2>PDA International Dental Conference 2025</h2>
                                </div>
                                <div class="details">
                                    <p>
                                        Join us for Pakistan’s largest dental gathering at <strong>Expo Center,
                                            Lahore</strong> from
                                        <strong>26–28 December 2025</strong>. Experience three days of cutting-edge
                                        research, live workshops,
                                        scientific sessions, and networking with global dental experts.
                                    </p>
                                    <p>
                                        Discover the future of dentistry through innovation, technology, and
                                        collaboration —
                                        all under one roof. Don’t miss this opportunity to connect with leaders shaping
                                        modern dentistry.
                                    </p>
                                    <div class="btns">
                                        <a href="{{ route('register.page') }}" class="btn events-theme-btn-red">Register Now</a>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end events-about -->


        <!-- start event-speakers -->
        <section class="event-speakers section-padding" id="speakers"  style="display:none;">
            <div class="container">
                <div class="row events-section-title">
                    <h2>Event speakers</h2>
                </div> <!-- end section-title -->

                <div class="row">
                    <div class="col col-md-5 left-col">
                        <div class="box">
                            <div class="img-holder-social">
                                <div class="img-holder">
                                    <img src="/assets/images/events/speakers/img-1.jpg" alt class="img img-responsive">
                                </div>
                                <div class="social">
                                    <ul class="social-links">
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="details">
                                <h3>Hasib sharif</h3>
                                <span>Keynote speaker</span>
                            </div>
                        </div>
                    </div>

                    <div class="col col-md-7 right-col">
                        <div class="box">
                            <div class="img-holder-social">
                                <div class="img-holder">
                                    <img src="/assets/images/events/speakers/img-2.jpg" alt class="img img-responsive">
                                </div>
                                <div class="social">
                                    <ul class="social-links">
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="details">
                                <h3>Hasib sharif</h3>
                                <span>Keynote speaker</span>
                            </div>
                        </div>
                        <div class="box">
                            <div class="img-holder-social">
                                <div class="img-holder">
                                    <img src="/assets/images/events/speakers/img-3.jpg" alt
                                        class="img img-responsive">
                                </div>
                                <div class="social">
                                    <ul class="social-links">
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="details">
                                <h3>Hasib sharif</h3>
                                <span>Keynote speaker</span>
                            </div>
                        </div>
                        <div class="box">
                            <div class="img-holder-social">
                                <div class="img-holder">
                                    <img src="/assets/images/events/speakers/img-4.jpg" alt
                                        class="img img-responsive">
                                </div>
                                <div class="social">
                                    <ul class="social-links">
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="details">
                                <h3>Hasib sharif</h3>
                                <span>Keynote speaker</span>
                            </div>
                        </div>
                        <div class="box">
                            <div class="img-holder-social">
                                <div class="img-holder">
                                    <img src="/assets/images/events/speakers/img-5.jpg" alt
                                        class="img img-responsive">
                                </div>
                                <div class="social">
                                    <ul class="social-links">
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="details">
                                <h3>Hasib sharif</h3>
                                <span>Keynote speaker</span>
                            </div>
                        </div>
                        <div class="box">
                            <div class="img-holder-social">
                                <div class="img-holder">
                                    <img src="/assets/images/events/speakers/img-6.jpg" alt
                                        class="img img-responsive">
                                </div>
                                <div class="social">
                                    <ul class="social-links">
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="details">
                                <h3>Hasib sharif</h3>
                                <span>Keynote speaker</span>
                            </div>
                        </div>
                        <div class="box">
                            <div class="img-holder-social">
                                <div class="img-holder">
                                    <img src="/assets/images/events/speakers/img-7.jpg" alt
                                        class="img img-responsive">
                                </div>
                                <div class="social">
                                    <ul class="social-links">
                                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                        <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                        <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="details">
                                <h3>Hasib sharif</h3>
                                <span>Keynote speaker</span>
                            </div>
                        </div>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end event-speakers -->


        <!-- start event-schedules -->
        <section class="event-schedules section-padding" id="schedules">
            <div class="container">
                <div class="row events-section-title">
                    <h2>Event schedules</h2>
                </div> <!-- end section-title -->

                <div class="row">
                    <div class="col col-xs-12">
                        <div class="event-schedules-content">
                            <ul class="tab-list">
                                <li class="active">
                                    <a href="#tab-1" data-toggle="tab">
                                        <span>Day 01</span>
                                        <h4>Dec 26</h4>
                                    </a>
                                </li>
                                <li>
                                    <a href="#tab-2" data-toggle="tab">
                                        <span>Day 02</span>
                                        <h4>Dec 27</h4>
                                    </a>
                                </li>
                                <li>
                                    <a href="#tab-3" data-toggle="tab">
                                        <span>Day 03</span>
                                        <h4>Dec 28</h4>
                                    </a>
                                </li>
                            </ul>

                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="tab-1">
                                    <div class="event">
                                        <div class="sidebar">
                                            <ul>
                                                <li>
                                                    <span class="icon"><i class="fa fa-clock-o"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Time</li>
                                                            <li>9:00 AM - 12:00 PM</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li>
                                                    <span class="icon"><i class="fa fa-map-marker"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Location</li>
                                                            <li>Expo Center, Lahore</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                {{-- <li>
                                                    <span class="icon"><i class="fa fa fa-microphone"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Speakers</li>
                                                            <li>Daniel Creek</li>
                                                            <li>Mostafa Malek</li>
                                                            <li>Rachel Bettany</li>
                                                        </ul>
                                                    </div>
                                                </li> --}}
                                            </ul>
                                        </div> <!-- end sidebar -->

                                        <div class="event-details">
                                            <h3>Coming Soon</h3>
                                            {{-- <p>Ned ut perspiciatis unde omnis iste natus error sit voluptatem
                                                accusantium dolor emque laudantium, totam rem aperiam, eaque ipsa quae
                                                ab illo inventore veritatis et quasi architecto beatae vitae dicta.Ned
                                                ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                                                dolor emque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                                                inventore veritatis et quasi architecto beatae vitae dicta.</p>
                                            <div class="spakers-pic">
                                                <ul>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-1.jpg" alt>
                                                    </li>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-2.jpg" alt>
                                                    </li>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-3.jpg" alt>
                                                    </li>
                                                </ul>
                                            </div> --}}
                                        </div>
                                    </div> <!-- end event -->

                                    <div class="event">
                                        <div class="sidebar">
                                            <ul>
                                                <li>
                                                    <span class="icon"><i class="fa fa-clock-o"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Time</li>
                                                            <li>9:00 AM - 12:00 PM</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li>
                                                    <span class="icon"><i class="fa fa-map-marker"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Location</li>
                                                            <li>Expo Center, Lahore</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                {{-- <li>
                                                    <span class="icon"><i class="fa fa fa-microphone"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Speakers</li>
                                                            <li>Daniel Creek</li>
                                                            <li>Mostafa Malek</li>
                                                            <li>Rachel Bettany</li>
                                                        </ul>
                                                    </div>
                                                </li> --}}
                                            </ul>
                                        </div> <!-- end sidebar -->

                                        {{-- <div class="event-details"> --}}
                                        {{-- <h3>Coming Soon</h3> --}}
                                        {{-- <p>Ned ut perspiciatis unde omnis iste natus error sit voluptatem
                                                accusantium dolor emque laudantium, totam rem aperiam, eaque ipsa quae
                                                ab illo inventore veritatis et quasi architecto beatae vitae dicta.Ned
                                                ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                                                dolor emque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                                                inventore veritatis et quasi architecto beatae vitae dicta.</p>
                                            <div class="spakers-pic">
                                                <ul>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-1.jpg" alt>
                                                    </li>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-2.jpg" alt>
                                                    </li>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-3.jpg" alt>
                                                    </li>
                                                </ul>
                                            </div> --}}
                                        {{-- </div> --}}
                                    </div> <!-- end event -->
                                </div> <!-- end tab-pane -->

                                <div class="tab-pane fade" id="tab-2">
                                    <div class="event">
                                        <div class="sidebar">
                                            <ul>
                                                <li>
                                                    <span class="icon"><i class="fa fa-clock-o"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Time</li>
                                                            <li>9:00 AM - 12:00 PM</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li>
                                                    <span class="icon"><i class="fa fa-map-marker"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Location</li>
                                                            <li>Expo Center, Lahore</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li>
                                                    <span class="icon"><i class="fa fa fa-microphone"></i></span>
                                                    <div class="info">
                                                        {{-- <ul>
                                                            <li>Speakers</li>
                                                            <li>Daniel Creek</li>
                                                            <li>Mostafa Malek</li>
                                                            <li>Rachel Bettany</li>
                                                        </ul> --}}
                                                    </div>
                                                </li>
                                            </ul>
                                        </div> <!-- end sidebar -->

                                        <div class="event-details">
                                            <h3>Coming Soon</h3>
                                            {{-- <p>Ned ut perspiciatis unde omnis iste natus error sit voluptatem
                                                accusantium dolor emque laudantium, totam rem aperiam, eaque ipsa quae
                                                ab illo inventore veritatis et quasi architecto beatae vitae dicta.Ned
                                                ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                                                dolor emque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                                                inventore veritatis et quasi architecto beatae vitae dicta.</p>
                                            <div class="spakers-pic">
                                                <ul>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-1.jpg" alt>
                                                    </li>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-2.jpg" alt>
                                                    </li>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-3.jpg" alt>
                                                    </li>
                                                </ul>
                                            </div> --}}
                                        </div>
                                    </div> <!-- end event -->

                                    <div class="event">
                                        <div class="sidebar">
                                            <ul>
                                                <li>
                                                    <span class="icon"><i class="fa fa-clock-o"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Time</li>
                                                            <li>9:00 AM - 12:00 PM</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li>
                                                    <span class="icon"><i class="fa fa-map-marker"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Location</li>
                                                            <li>Expo Center, Lahore</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li>
                                                    <span class="icon"><i class="fa fa fa-microphone"></i></span>
                                                    <div class="info">
                                                        {{-- <ul>
                                                            <li>Speakers</li>
                                                            <li>Daniel Creek</li>
                                                            <li>Mostafa Malek</li>
                                                            <li>Rachel Bettany</li>
                                                        </ul> --}}
                                                    </div>
                                                </li>
                                            </ul>
                                        </div> <!-- end sidebar -->

                                        <div class="event-details">
                                            <h3>Coming Soon</h3>
                                            {{-- <p>Ned ut perspiciatis unde omnis iste natus error sit voluptatem
                                                accusantium dolor emque laudantium, totam rem aperiam, eaque ipsa quae
                                                ab illo inventore veritatis et quasi architecto beatae vitae dicta.Ned
                                                ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                                                dolor emque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                                                inventore veritatis et quasi architecto beatae vitae dicta.</p>
                                            <div class="spakers-pic">
                                                <ul>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-1.jpg" alt>
                                                    </li>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-2.jpg" alt>
                                                    </li>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-3.jpg" alt>
                                                    </li>
                                                </ul>
                                            </div> --}}
                                        </div>
                                    </div> <!-- end event -->
                                </div>

                                <div class="tab-pane fade" id="tab-3">
                                    <div class="event">
                                        <div class="sidebar">
                                            <ul>
                                                <li>
                                                    <span class="icon"><i class="fa fa-clock-o"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Time</li>
                                                            <li>9:00 AM - 12:00 PM</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li>
                                                    <span class="icon"><i class="fa fa-map-marker"></i></span>
                                                    <div class="info">
                                                        <ul>
                                                            <li>Location</li>
                                                            <li>Expo Center, Lahore</li>
                                                        </ul>
                                                    </div>
                                                </li>
                                                <li>
                                                    <span class="icon"><i class="fa fa fa-microphone"></i></span>
                                                    <div class="info">
                                                        {{-- <ul>
                                                            <li>Speakers</li>
                                                            <li>Daniel Creek</li>
                                                            <li>Mostafa Malek</li>
                                                            <li>Rachel Bettany</li>
                                                        </ul> --}}
                                                    </div>
                                                </li>
                                            </ul>
                                        </div> <!-- end sidebar -->

                                        <div class="event-details">
                                            <h3>Coming Soon</h3>
                                            {{-- <p>Ned ut perspiciatis unde omnis iste natus error sit voluptatem
                                                accusantium dolor emque laudantium, totam rem aperiam, eaque ipsa quae
                                                ab illo inventore veritatis et quasi architecto beatae vitae dicta.Ned
                                                ut perspiciatis unde omnis iste natus error sit voluptatem accusantium
                                                dolor emque laudantium, totam rem aperiam, eaque ipsa quae ab illo
                                                inventore veritatis et quasi architecto beatae vitae dicta.</p>
                                            <div class="spakers-pic">
                                                <ul>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-1.jpg" alt>
                                                    </li>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-2.jpg" alt>
                                                    </li>
                                                    <li><img src="/assets/images/events/speakers-thumb/img-3.jpg" alt>
                                                    </li>
                                                </ul>
                                            </div> --}}
                                        </div>
                                    </div> <!-- end event -->
                                </div>
                            </div> <!-- end tab-content -->
                        </div> <!-- end event-schedules-content -->
                    </div> <!-- end col -->
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end event-schedules -->


        <!-- start pricing-->
        <section class="pricing event-pricing section-padding">
            <div class="container">
                <div class="row events-section-title">
                    <h2>Our Registration pricing</h2>
                </div> <!-- end section-title -->
                <section class="charity-gallery">

                    <div class="gallery-filters">
                        <ul>
                            <li><a onclick="showAll('')" href="#" class="current">All</a></li>
                            <li><a onclick="showAll('Conference')" href="#">Conference</a></li>
                            <!--<li><a onclick="showAll('Workshop')" href="#">Workshop</a></li>-->

                        </ul>
                    </div>
                </section>

                <div class="row ">
                    @foreach ($types as $type)
                        {{-- @dd($type) --}}
                        <div class="col col-md-4 col-sm-6 content Conference">
                            <div class="pricing-grid wow fadeInLeftSlow" data-wow-delay="0.3s">
                                <div class="pricing-header">
                                    <h3>{{ $type['name'] }}</h3>
                                    <span>{{ $type['price'] }}</span>
                                </div>
                                <div class="pricing-details">
                                    {{-- <ul>
                                    <li><i class="fa fa-check"></i> perspiciatis unde omnis iste</li>
                                    <li><i class="fa fa-check"></i> natus error sit volupta</li>
                                    <li><i class="fa fa-check"></i> accusantium dolorem laud</li>
                                    <li><i class="fa fa-close"></i> antium totam rem aper</li>
                                    <li><i class="fa fa-close"></i> aque ipsa quae</li>
                                </ul> --}}
                                </div>

                                <a href="{{ route('register.page') }}" class="btn theme-btn">Register Now</a>
                            </div>
                        </div>
                    @endforeach
                    <!--  @foreach ($types_shops as $type)-->
                    <!--    {{-- @dd($type) --}}-->
                    <!--    <div class="col col-md-4 col-sm-6 content Workshop">-->
                    <!--        <div class="pricing-grid wow fadeInLeftSlow" data-wow-delay="0.3s">-->
                    <!--            <div class="pricing-header">-->
                    <!--                <h3>{{ $type['name'] }}</h3>-->
                    <!--                <span>{{ $type['price'] }}</span>-->
                    <!--            </div>-->
                    <!--            <div class="pricing-details">-->
                    <!--                {{-- <ul>-->
                    <!--                <li><i class="fa fa-check"></i> perspiciatis unde omnis iste</li>-->
                    <!--                <li><i class="fa fa-check"></i> natus error sit volupta</li>-->
                    <!--                <li><i class="fa fa-check"></i> accusantium dolorem laud</li>-->
                    <!--                <li><i class="fa fa-close"></i> antium totam rem aper</li>-->
                    <!--                <li><i class="fa fa-close"></i> aque ipsa quae</li>-->
                    <!--            </ul> --}}-->
                    <!--            </div>-->

                    <!--            <a href="{{ route('register.page') }}" class="btn theme-btn">Register Now</a>-->
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--@endforeach-->


                </div>
                <div class="row content" style="margin-top: 23px;">
                  


                </div>
                
                <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end pricing-->


        <!-- start event-booking -->
        <section class="event-booking section-padding" id="ticket">
            <div class="container">
                <div class="row events-section-title">
                    <h2>Reserve your Spot</h2>
                </div> <!-- end section-title -->

                <div class="row">
                    <div class="col col-xs-12">
                        <form class="form row" action="{{ route('register.page') }}" method="get">

                            <div class="col col-sm-12 submit-col">
                                <button type="submit" class="btn events-theme-btn-red">Register now</button>
                            </div>
                        </form>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>
        <!-- end event-booking -->


        <!-- start charity-gallery -->
        <section class="charity-gallery events-gallery section-padding" id="gallery">
            <h2 class="hidden">Gallery</h2>
            <div class="row events-section-title">
                <h2>Conference gallery</h2>
            </div> <!-- end section-title -->

            <div class="row">
                <div class="col col-lg-12">
                    <div class="gallery-filters">
                        <ul>
                            <!--<li><a data-filter="*" href="#" class="current">All</a></li>-->
                            <!--<li><a data-filter=".2015" href="#">2015</a></li>-->
                            <!--<li><a data-filter=".2017" href="#">2017</a></li>-->
                            <!--<li><a data-filter=".2018" href="#">2018</a></li>-->
                            <!--<li><a data-filter=".2024" href="#">2024</a></li>-->
                        </ul>
                    </div>


                    <div class="gallery-container popup-gallery">
                        <div class="box branding">
                            <a href="/assets/images/events/gallery/img-1.jpg">
                                <div class="img-holder">
                                    <img src="/assets/images/events/gallery/img-1.jpg" alt class="img img-responsive">
                                </div>
                                <div class="hover-text" style="display:none">
                                    <div>
                                        <span>Fashion</span>
                                        <h3>Crossfit : 15.4 open workout</h3>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="box photography">
                            <a href="/assets/images/events/gallery/img-2.jpg">
                                <div class="img-holder">
                                    <img src="/assets/images/events/gallery/img-2.jpg" alt class="img img-responsive">
                                </div>
                                <div class="hover-text" style="display:none">
                                    <div>
                                        <span>Fashion</span>
                                        <h3>Crossfit : 15.4 open workout</h3>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="box photography">
                            <a href="/assets/images/events/gallery/img-3.jpg">
                                <div class="img-holder">
                                    <img src="/assets/images/events/gallery/img-3.jpg" alt class="img img-responsive">
                                </div>
                                <div class="hover-text" style="display:none">
                                    <div>
                                        <span>Fashion</span>
                                        <h3>Crossfit : 15.4 open workout</h3>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="box branding others web">
                            <a href="/assets/images/events/gallery/img-4.jpg">
                                <div class="img-holder">
                                    <img src="/assets/images/events/gallery/img-4.jpg" alt class="img img-responsive">
                                </div>
                                <div class="hover-text" style="display:none">
                                    <div>
                                        <span>Fashion</span>
                                        <h3>Crossfit : 15.4 open workout</h3>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="box branding web">
                            <a href="/assets/images/events/gallery/img-5.jpg">
                                <div class="img-holder">
                                    <img src="/assets/images/events/gallery/img-5.jpg" alt class="img img-responsive">
                                </div>
                                <div class="hover-text" style="display:none">
                                    <div>
                                        <span>Fashion</span>
                                        <h3>Crossfit : 15.4 open workout</h3>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="box branding web">
                            <a href="/assets/images/events/gallery/img-6.jpg">
                                <div class="img-holder">
                                    <img src="/assets/images/events/gallery/img-6.jpg" alt class="img img-responsive">
                                </div>
                                <div class="hover-text" style="display:none">
                                    <div>
                                        <span>Fashion</span>
                                        <h3>Crossfit : 15.4 open workout</h3>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="box web">
                            <a href="/assets/images/events/gallery/img-7.jpg">
                                <div class="img-holder">
                                    <img src="/assets/images/events/gallery/img-7.jpg" alt class="img img-responsive">
                                </div>
                                <div class="hover-text" style="display:none">
                                    <div>
                                        <span>Fashion</span>
                                        <h3>Crossfit : 15.4 open workout</h3>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="box branding web">
                            <a href="/assets/images/events/gallery/img-8.jpg">
                                <div class="img-holder">
                                    <img src="/assets/images/events/gallery/img-8.jpg" alt class="img img-responsive">
                                </div>
                                <div class="hover-text" style="display:none">
                                    <div>
                                        <span>Fashion</span>
                                        <h3>Crossfit : 15.4 open workout</h3>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
        </section>
        <!-- end charity-gallery -->





        <!-- start event-sponsors -->
        <section class="event-spnosors section-padding">
            <div class="container my-5">
    <div class="row events-section-title text-center mb-5">
        <div class="col-12">
            <h2 class="fw-bold">Our Partners</h2>
        </div>
    </div>

    <div class="row sponsors text-center justify-content-center">
        <!-- Academic Partner -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
            <h3>Academic Partner:</h3>
            <div class="partner-box">
                <a href="#">
                    <img src="/Iadsr.png" alt="Academic Partner" class="img-fluid partner-logo">
                </a>
            </div>
        </div>

        <!-- Marketing Partner -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
            <h3>Marketing Partner:</h3>
            <div class="partner-box">
                <a href="#">
                    <img src="/fm_logo.png" alt="Marketing Partner" class="img-fluid partner-logo">
                </a>
            </div>
        </div>

        <!-- Media Partner -->
        <div class="col-lg-4 col-md-6 col-sm-12 mb-4">
            <h3>Media Partner:</h3>
            <div class="partner-box white-bg">
                <a href="#">
                    <img src="/dental_logo.png" alt="Media Partner" class="img-fluid partner-logo">
                </a>
            </div>
        </div>
    </div>
</div>
<!-- end container -->
        </section>
        <div class="mt-4" style="margin-top: 20px;">

        </div>
        <section class="event-spnosors section-padding">
            <div class="container">
                <div class="row events-section-title">
                    <h2>Our Collaborator</h2>
                </div> <!-- end section-title -->

                <div class="row sponsors">
                    <div class="col col-xs-12">
                        {{-- <h3>Platinum Sponsors:</h3> --}}
                         
    <!--                    <div class="box white-bg" style="margin-right: 20px;-->
    <!--width: 17% !important;">-->
    <!--                        <a href="#"><img src="/assets/images/events/sponsors/10.png" alt-->
    <!--                                class="img img-responsive"></a>-->
    <!--                    </div>-->
    <!--                    <div class="box white-bg" style="margin-right: 20px;-->
    <!--width: 17% !important;">-->
    <!--                        <a href="#"><img src="/assets/images/events/sponsors/2.png" alt-->
    <!--                                class="img img-responsive"></a>-->
    <!--                    </div>-->
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/4.png" alt
                                    class="img img-responsive"></a>
                        </div>
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/5.png" alt
                                    class="img responsive"></a>
                        </div>
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/8.png" alt
                                    class="img img-responsive"></a>
                        </div>
                          <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/1.png" alt
                                    class="img img-responsive"></a>
                        </div>
                         <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/6.png" alt
                                    class="img img-responsive"></a>
                        </div>
                        
                       
                       
                    </div>
                </div>
                <div class="row sponsors" style="margin-top: 20px;">
                    <div class="col col-xs-12">
                        {{-- <h3>Platinum Sponsors:</h3> --}}
                       
                        
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/3.png" alt
                                    class="img img-responsive"></a>
                        </div>
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/7.png" alt
                                    class="img responsive"></a>
                        </div>
                        
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/9.png" alt
                                    class="img img-responsive"></a>
                        </div>
                       
                    </div>

                </div> <!-- end row -->
                {{-- <div class="row sponsors gold-sponsors">
                    <div class="col col-xs-12">
                        <h3>Gold Sponsors:</h3>
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/img-6.png" alt
                                    class="img img-responsive"></a>
                        </div>
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/img-7.png" alt
                                    class="img img-responsive"></a>
                        </div>
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/img-8.png" alt
                                    class="img img-responsive"></a>
                        </div>
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/img-9.png" alt
                                    class="img img-responsive"></a>
                        </div>
                        <div class="box">
                            <a href="#"><img src="/assets/images/events/sponsors/img-10.png" alt
                                    class="img img-responsive"></a>
                        </div>
                    </div>
                </div> <!-- end row --> --}}
            </div> <!-- end container -->
        </section>
        <!-- end event-sponsors -->
        <div class="mt-4" style="margin-top: 20px;">

        </div>

        <!-- start event-location -->
        <section class="event-contact" id="contact">
            <h2 class="hidden">Contact info</h2>
            <div class="map">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3403.12752534471!2d74.25763187532202!3d31.465677974238975!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3919022a17a84c4b%3A0x74ef403a4d0bb9a4!2sExpo%20Centre%20Lahore!5e0!3m2!1sen!2s!4v1760694858423!5m2!1sen!2s"
                    width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <div class="container">
                <div class="row contact-address section-padding">
                  <h2 style="text-align: center; margin: 36px;">Contact Information</h2>
                    
                    <div class="col col-md-4">
                        <ul class="contact-info">
                           
                            <li><i class="fa fa-phone"></i> +92 333 4214214</li>
                            <li><i class="fa fa-envelope"></i>marketing@iadsr.edu.pk</li>
                        </ul>
                    </div>
                    <div class="col col-md-8">
                        <div id="contact-success" class="alert alert-success" style="display:none;">
    Thank you! Your message has been sent.
</div>
                        <form id="contactForm" class="form row">
    <div class="col col-md-6">
        <input type="text" name="first_name" class="form-control" placeholder="First name.." required>
    </div>
    <div class="col col-md-6">
        <input type="text" name="last_name" class="form-control" placeholder="Last name.." required>
    </div>
    <div class="col col-md-6">
        <input type="email" name="email" class="form-control" placeholder="Email address.." required>
    </div>
    <div class="col col-md-6">
        <input type="text" name="phone" class="form-control" placeholder="Phone.." required>
    </div>
    <div class="col col-md-12">
        <textarea name="message" class="form-control" placeholder="Write.." required></textarea>
    </div>
    <div class="col col-md-12 submit">
        <button type="submit" class="btn events-theme-btn-red">Submit</button>
    </div>
</form>


                    </div>
                </div>
            </div> 
        </section>
       
        <div class="mt-4" style="margin-top: 20px;">

        </div>

       
        
        


        <!-- start footer -->
        <!--<footer class="event-footer">-->
        <!--    <div class="container">-->
        <!--        <div class="row">-->
        <!--            <div class="col col-xs-12">-->
        <!--                <div class="logo">-->
        <!--                    <img src="/assets/images/events/sponsors/fm_logo.png" style="width: 200px;" alt>-->
        <!--                </div>-->
        <!--                <div class="copyright">-->
        <!--                    <p>2025 &copy; Design and Develop By <a href="https://fissionmonster.com">Fission-->
        <!--                            Monster</a></p>-->
        <!--                </div>-->
        <!--                <div>-->
        <!--                    <ul class="social-links">-->
        <!--                        <li><a href="https://www.linkedin.com/company/fissionmonster/?originalSubdomain=pk"><i-->
        <!--                                    class="fa fa-linkedin"></i></a></li>-->
        <!--                        <li><a href="https://www.facebook.com/fissionmonster"><i-->
        <!--                                    class="fa fa-facebook"></i></a></li>-->
        <!--                        <li><a href="https://www.instagram.com/fissionmonster/"><i-->
        <!--                                    class="fa fa-instagram"></i></a></li>-->
        <!--                        {{-- <li><a href="#"><i class="fa fa-linkedin"></i></a></li>-->
        <!--                        <li><a href="#"><i class="fa fa-behance"></i></a></li> --}}-->
        <!--                    </ul>-->
        <!--                </div>-->
        <!--            </div>-->
        <!--        </div>-->
        <!--    </div> <!-- end container -->-->
        <!--</footer>-->
        
      <section class="event-newsletter section-padding">
    <h2 class="hidden">Newsletter</h2>
    <div class="container">
        <div class="row">
            <div class="col col-md-8 col-md-offset-2">
                <p>Subscribe to get the latest update</p>

                {{-- Show success or error messages --}}
                @if (session('success'))
                    <div class="alert alert-success">{{ session('success') }}</div>
                @endif
                @error('email')
                    <div class="alert alert-danger">{{ $message }}</div>
                @enderror

                <form class="form" method="POST" action="{{ route('subscribe.store') }}">
                    @csrf
                    <div>
                        <input type="email" class="form-control" placeholder="Type your email" required name="email">
                    </div>
                    <div class="submit mt-2" style="margin-top: 20px;float: left;">
                        <button class="btn events-theme-btn-red" type="submit">Subscribe</button>
                    </div>
                </form>
            </div>
        </div> 
    </div> 
</section>

        <footer class="footer-style-two" id="contact">
            <div class="container">
                <div class="row">
                    <div class="col col-md-4 col-xs-6">
                        <div class="widget about-widget">
                            <div class="logo"><a href="#"><img src="/assets/images/events/sponsors/fm_logo.png" style="width: 200px;" alt="" class="img img-responsive"></a></div>
                            
                            <p class="copyright">2025 &copy; Design and Develop By <a href="https://fissionmonster.com">Fission
                                    Monster</p>
                            <ul class="social-links">
                                <li><a href="https://www.linkedin.com/company/fissionmonster/?originalSubdomain=pk"><i
                                            class="fa fa-linkedin"></i></a></li>
                                <li><a href="https://www.facebook.com/fissionmonster"><i
                                            class="fa fa-facebook"></i></a></li>
                                <li><a href="https://www.instagram.com/fissionmonster/"><i
                                            class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col col-md-4 col-xs-6">
                        <div class="widget contact-widget">
                            <h3>Contact</h3>
                           
                            <ul>
                                <li><span>Email: </span>hello@fissionmonster.com</li>
                                <li><span>Phone: </span>+92 3314547089</li>
                            </ul>
                        </div>
                    </div>

                    <div class="col col-md-4 col-xs-6">
                        <div class="widget site-map">
                            <h3>Site map</h3>
                            <ul>
                                <li><a  href="#home">Home</a></li>
                                <li><a  href="#about">Conference</a></li>
                                <li><a  href="{{ route('register.page') }}">Register Now</a></li>
                                <li><a href="https://iadsr.edu.pk/conference/">Our Portfolio</a></li>
                                
                            </ul>
                        </div>
                    </div>

                    
                </div> <!-- end row -->
            </div> <!-- end container -->
        </footer>
        <!-- end footer -->
    </div>
    <!-- end of page-wrapper -->


    <!-- All JavaScript files
    ================================================== -->
    <!--<script src="/assets/js/jquery.min.js"></script>-->
    <script type="text/javascript" src="https://cdn-script.com/ajax/libs/jquery/3.7.1/jquery.js"></script>
    <script src="/assets/js/bootstrap.min.js"></script>

    <!-- Plugins for this template -->
    <script src="/assets/js/jquery-plugin-collection.js"></script>

    <!-- Google map api -->
    {{-- <script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyC348vlw53nvT6C8LQ_dxkvsWDb9Kd2mEw"></script> --}}

    <!-- Custom script for this template -->
    <script src="/assets/js/script.js"></script>

    <script>
        function showAll(className) {


            if (className == "Conference") {
                $('.Conference').show();
                $('.Workshop').hide();
            } else if (className == "Workshop") {
                $('.Conference').hide();
                $('.Workshop').show();
            } else {
                $('.Conference').show();
                $('.Workshop').show();
            }
        }
    </script>
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        @if (Session::has('success'))
            Swal.fire({
                title: "Good job!",
                text: "Register Successfully Our Team Contact You Shortly",
                icon: "success"
            });
        @endif
        @if (Session::has('message'))
            Swal.fire({
                title: "Good job!",
                text: "Thank you for subscribing!",
                icon: "success"
            });
        @endif
        @if (Session::has('error'))
        @endif
    </script>
    
    <script>
document.getElementById("contactForm").addEventListener("submit", function(e) {
    e.preventDefault();

    fetch("{{ route('contact.submit') }}", {
        method: "POST",
        headers: {
            "X-CSRF-TOKEN": "{{ csrf_token() }}",
        },
        body: new FormData(this)
    })
    .then(res => res.ok ? res.text() : Promise.reject(res))
    .then(() => {
        document.getElementById("contact-success").style.display = "block";
        document.getElementById("contact-success").scrollIntoView({ behavior: "smooth", block: "center" });
        this.reset();
        setTimeout(() => document.getElementById("contact-success").style.display = "none", 5000);
    })
    .catch(() => alert("Something went wrong! Please try again."));
});
</script>
</body>

</html>
